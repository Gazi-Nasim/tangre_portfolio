<script src="<?php echo e(asset('front_assets/js/vendor/jquery.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
    crossorigin="anonymous"></script>
<script src="<?php echo e(asset('front_assets/js/vendor/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
<script src="<?php echo e(asset('front_assets/js/easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('front_assets/js/hoverIntent.js')); ?>"></script>
<script src="<?php echo e(asset('front_assets/js/superfish.min.js')); ?>"></script>
<script src="<?php echo e(asset('front_assets/js/jquery.ajaxchimp.min.js')); ?>"></script>
<script src="<?php echo e(asset('front_assets/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('front_assets/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('front_assets/js/isotope.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('front_assets/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('front_assets/js/jquery.nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('front_assets/js/jquery.lightbox.js')); ?>"></script>
<script src="<?php echo e(asset('front_assets/js/mail-script.js')); ?>"></script>
<script src="<?php echo e(asset('front_assets/js/main.js')); ?>"></script>
<?php echo $__env->yieldContent('extra_script'); ?><?php /**PATH D:\server\htdocs\tangre_portfolio\resources\views/front_layout/footer_assets.blade.php ENDPATH**/ ?>