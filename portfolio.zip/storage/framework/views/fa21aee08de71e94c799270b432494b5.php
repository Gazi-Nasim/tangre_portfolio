<!DOCTYPE html>
<html lang="zxx" class="no-js">

<head>
    <?php echo $__env->make('front_layout.head_assets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <!--################ Start Header Area ########-->
    <?php echo $__env->make('front_layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--######## End Header Area ########-->
    <?php echo $__env->yieldContent('content'); ?>
    <!--######## start footer Area ########-->
    <?php echo $__env->make('front_layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--######## End footer Area ########-->
    <?php echo $__env->make('front_layout.footer_assets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH D:\server\htdocs\tangre_portfolio\resources\views/front_layout/app.blade.php ENDPATH**/ ?>