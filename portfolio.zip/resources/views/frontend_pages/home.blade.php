@extends('front_layout.app')
@section('content')
<section class="home-banner-area relative" id="home">
    <div class="container">
        <div class="row fullscreen d-flex align-items-center">
            <div class="banner-content col-lg-9 col-md-12">
                <h1>
                    Creativity <br> Beyond <br> Life Hanki Panki
                </h1>
                <a href="#" class="primary-btn header-btn text-capitalize mt-10">hire us now!</a>
            </div>
        </div>
    </div>
</section>
@section('extra_script')
<script>
    // alert("nice")
</script>
@endsection
@endsection